/*:
 [Table of Contents](Table%20of%20Contents) | [Previous](@previous)
 ****
 */
import Foundation
//: ## Challenge
//: **This exercise is completely optional and is not required for completing the Swift Problem Set.**
//: ### Challenge 1
//: Mystery code! What does this code do? Briefly, using comments, describe what is happening in each line. **Hint**: You may need to look up [Int initializers](http://stackoverflow.com/questions/30739460/toint-removed-in-swift-2).
let array = ["A", "13", "B", "5", "87", "t", "41"] // Stores a series of Strings as a Constant in an Array called array
var sum = 0                                        // Stores an Int "0" as the sum
for string in array {                              // assigns a var name of string to each individual string in the array
    if Int(string) != nil {                        // if the string is not empty then
        let intToAdd = Int(string)!                // assign that string to intToAdd as an integar and then
        sum += intToAdd                            // add that ints value to the sum
    }
}
print(sum)                                         // prints the variable sum which was reassigned during the "for in" loop


var name: String = "14"
var nameValue = Int(name)!


/*:
 ****
 [Table of Contents](Table%20of%20Contents) | [Previous](@previous)
 */
